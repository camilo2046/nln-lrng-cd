package org.mongodb.morphia.logging;

/**
 * @deprecated Use Logger directly
 */
@Deprecated
public interface Logr extends Logger {

}
